export interface TradeSignal {
  date: string;
  timeframe: string;
  pair: string;
  time: string;
  direction: 'PUT' | 'CALL';
  result: 'win' | 'loss';
  martingaleLevel?: number;
}

export interface MartingaleSeries {
  trades: TradeSignal[];
  result: 'won' | 'lost';
  profit: number;
  stake: number;
}

export interface BacktestResults {
  totalTrades: number;
  seriesWon: number;
  seriesLost: number;
  winRate: number;
  finalCapital: number;
  netProfit: number;
  maxDrawdown: number;
  longestWinStreak: number;
  longestLossStreak: number;
  dailyResults: DailyResult[];
  allSeries: MartingaleSeries[];
  debugInfo?: {
    baseStake: number;
    seriesDetails: Array<{
      pair: string;
      direction: string;
      level: number;
      profit: number;
      totalStake: number;
      netProfit: number;
      trades?: Array<{
        time: string;
        emoji: string;
        level: number;
        profit: number;
      }>;
    }>;
  };
}

export interface DailyResult {
  date: string;
  trades: number;
  wins: number;
  losses: number;
  profit: number;
  balance: number;
}

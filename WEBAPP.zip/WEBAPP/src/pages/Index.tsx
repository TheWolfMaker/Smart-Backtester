import { useState } from 'react';
import { FileUpload } from '@/components/FileUpload';
import { ConfigurationPanel, BacktestConfig } from '@/components/ConfigurationPanel';
import { ResultsMetrics } from '@/components/ResultsMetrics';
import { TimeframeAnalysis } from '@/components/TimeframeAnalysis';
import { BalanceChart } from '@/components/BalanceChart';
import { ResultsTable } from '@/components/ResultsTable';
import { parseSignalFile, filterSignalsByTime } from '@/utils/signalParser';
import { runBacktest } from '@/utils/backtestEngine';
import { BacktestResults, TradeSignal } from '@/types/backtest';
import { toast } from '@/hooks/use-toast';
import { BarChart } from 'lucide-react';

const Index = () => {
  const [signals, setSignals] = useState<TradeSignal[]>([]);
  const [results, setResults] = useState<BacktestResults | null>(null);
  const [config, setConfig] = useState<BacktestConfig>({
    payoutPercentage: 80,
    initialCapital: 1000,
    martingaleStructure: [1, 2, 4],
    startTime: '06:00',
    endTime: '23:59',
    timeframeFilter: 'ALL',
  });

  const handleFileUpload = (content: string, filename: string) => {
    try {
      const parsedSignals = parseSignalFile(content);
      setSignals(parsedSignals);
      setResults(null);
      toast({
        title: 'Archivo Cargado Exitosamente',
        description: `Se analizaron ${parsedSignals.length} seÃ±ales de trading desde ${filename}`,
      });
    } catch (error) {
      toast({
        title: 'Error al Analizar el Archivo',
        description: 'Por favor verifica el formato del archivo e intenta nuevamente.',
        variant: 'destructive',
      });
    }
  };

  const handleRunBacktest = () => {
    if (signals.length === 0) {
      toast({
        title: 'No Hay SeÃ±ales Cargadas',
        description: 'Por favor carga primero un archivo de seÃ±ales.',
        variant: 'destructive',
      });
      return;
    }

    try {
      // Filtrar por tiempo
      let filteredSignals = filterSignalsByTime(
        signals,
        config.startTime,
        config.endTime
      );

      // Filtrar por temporalidad
      if (config.timeframeFilter !== 'ALL') {
        filteredSignals = filteredSignals.filter(
          signal => signal.timeframe === config.timeframeFilter
        );
      }
      
      if (filteredSignals.length === 0) {
        toast({
          title: 'Sin SeÃ±ales',
          description: 'No se encontraron seÃ±ales con los filtros aplicados.',
          variant: 'destructive',
        });
        return;
      }

      const backtestResults = runBacktest(filteredSignals, config);
      setResults(backtestResults);

      const timeframeLabel = config.timeframeFilter === 'ALL' 
        ? 'M1 + M5' 
        : config.timeframeFilter;
      
      toast({
        title: 'Backtest Completado',
        description: `${timeframeLabel}: ${backtestResults.totalTrades} operaciones en ${backtestResults.dailyResults.length} dÃ­as`,
      });
    } catch (error) {
      toast({
        title: 'Error en el Backtest',
        description: 'OcurriÃ³ un error al ejecutar el backtest.',
        variant: 'destructive',
      });
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-gradient-primary">
              <BarChart className="w-6 h-6 text-primary-foreground" />
            </div>
            <div>
              <h1 className="text-2xl font-bold bg-gradient-primary bg-clip-text text-transparent">
                Smart Backtester
              </h1>
              <p className="text-sm text-muted-foreground">
                AnÃ¡lisis de Estrategia Martingala para Opciones Binarias
              </p>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8 space-y-8">
        {/* File Upload Section */}
        <section>
          <FileUpload onFileUpload={handleFileUpload} />
        </section>

        {/* Configuration Section */}
        {signals.length > 0 && (
          <section>
            <ConfigurationPanel
              config={config}
              onConfigChange={setConfig}
              onRunBacktest={handleRunBacktest}
            />
          </section>
        )}

        {/* Results Section */}
        {results && (
          <>
            <section>
              <ResultsMetrics results={results} />
            </section>

            <section>
              <TimeframeAnalysis allSeries={results.allSeries} config={config} />
            </section>

            <section className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <BalanceChart dailyResults={results.dailyResults} />
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="p-6 rounded-lg bg-card border border-border">
                    <p className="text-sm text-muted-foreground mb-1">Series Ganadas</p>
                    <p className="text-3xl font-bold text-success">{results.seriesWon}</p>
                  </div>
                  <div className="p-6 rounded-lg bg-card border border-border">
                    <p className="text-sm text-muted-foreground mb-1">Series Perdidas</p>
                    <p className="text-3xl font-bold text-destructive">{results.seriesLost}</p>
                  </div>
                  <div className="p-6 rounded-lg bg-card border border-border">
                    <p className="text-sm text-muted-foreground mb-1">Total Operaciones</p>
                    <p className="text-3xl font-bold text-foreground">{results.totalTrades}</p>
                  </div>
                  <div className="p-6 rounded-lg bg-card border border-border">
                    <p className="text-sm text-muted-foreground mb-1">Racha de PÃ©rdidas</p>
                    <p className="text-3xl font-bold text-muted-foreground">
                      {results.longestLossStreak}
                    </p>
                  </div>
                </div>
              </div>
            </section>

            <section>
              <ResultsTable dailyResults={results.dailyResults} />
            </section>

            {/* Reporte Detallado de Series */}
            <section className="p-6 rounded-lg bg-card border border-border">
              <h3 className="text-2xl font-bold mb-6 text-foreground">ðŸ“Š REPORTE DETALLADO DE SERIES</h3>
              
              {/* Resumen */}
              <div className="grid grid-cols-2 gap-4 mb-6 p-4 bg-muted/50 rounded-lg">
                <div>
                  <p className="text-sm text-muted-foreground">SERIES GANADAS</p>
                  <p className="text-3xl font-bold text-success">{results.seriesWon}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">SERIES PERDIDAS</p>
                  <p className="text-3xl font-bold text-destructive">{results.seriesLost}</p>
                </div>
              </div>

              {/* Series Ganadas */}
              <div className="mb-6">
                <h4 className="text-lg font-bold text-success mb-3">âœ… GANANCIAS POR SERIE GANADA:</h4>
                <div className="space-y-2 max-h-64 overflow-y-auto mb-3">
                  {results.allSeries
                    .filter(s => s.result === 'won')
                    .map((series, i) => {
                      const lastTrade = series.trades[series.trades.length - 1];
                      return (
                        <div key={i} className="p-3 bg-success/10 border border-success/20 rounded text-sm">
                          <span className="font-bold">{i + 1}.</span> {lastTrade.pair} - Nivel {lastTrade.martingaleLevel}: 
                          <span className="text-success font-bold"> +${series.profit.toFixed(2)}</span>
                        </div>
                      );
                    })}
                </div>
                <div className="p-4 bg-success/20 rounded-lg">
                  <p className="text-lg font-bold text-success">
                    Total Ganancias: +${results.allSeries
                      .filter(s => s.result === 'won')
                      .reduce((sum, s) => sum + s.profit, 0)
                      .toFixed(2)}
                  </p>
                </div>
              </div>

              {/* Series Perdidas */}
              <div className="mb-6">
                <h4 className="text-lg font-bold text-destructive mb-3">âŒ PÃ‰RDIDAS POR SERIE PERDIDA:</h4>
                <div className="space-y-2 max-h-64 overflow-y-auto mb-3">
                  {results.allSeries
                    .filter(s => s.result === 'lost')
                    .map((series, i) => {
                      const lastTrade = series.trades[series.trades.length - 1];
                      return (
                        <div key={i} className="p-3 bg-destructive/10 border border-destructive/20 rounded text-sm">
                          <span className="font-bold">{i + 1}.</span> {lastTrade.pair} - PÃ©rdida: 
                          <span className="text-destructive font-bold"> -${Math.abs(series.profit).toFixed(2)}</span>
                        </div>
                      );
                    })}
                </div>
                <div className="p-4 bg-destructive/20 rounded-lg">
                  <p className="text-lg font-bold text-destructive">
                    Total PÃ©rdidas: -${results.allSeries
                      .filter(s => s.result === 'lost')
                      .reduce((sum, s) => sum + Math.abs(s.profit), 0)
                      .toFixed(2)}
                  </p>
                </div>
              </div>

              {/* CÃ¡lculo Final */}
              <div className="p-6 bg-gradient-primary/10 border-2 border-primary rounded-lg">
                <h4 className="text-xl font-bold mb-4 text-primary">ðŸ’° CÃLCULO FINAL:</h4>
                <div className="space-y-2 font-mono text-sm">
                  <div className="flex justify-between">
                    <span>Capital Inicial:</span>
                    <span className="font-bold">${config.initialCapital.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-success">
                    <span>+ Ganancias series:</span>
                    <span className="font-bold">+${results.allSeries
                      .filter(s => s.result === 'won')
                      .reduce((sum, s) => sum + s.profit, 0)
                      .toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-destructive">
                    <span>- PÃ©rdidas series:</span>
                    <span className="font-bold">-${results.allSeries
                      .filter(s => s.result === 'lost')
                      .reduce((sum, s) => sum + Math.abs(s.profit), 0)
                      .toFixed(2)}</span>
                  </div>
                  <div className="h-px bg-border my-3"></div>
                  <div className="flex justify-between text-lg">
                    <span className="font-bold">= CAPITAL FINAL:</span>
                    <span className="font-bold text-primary">${results.finalCapital.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-lg">
                    <span className="font-bold">= PROFIT NETO:</span>
                    <span className={`font-bold ${results.netProfit >= 0 ? 'text-success' : 'text-destructive'}`}>
                      ${results.netProfit >= 0 ? '+' : ''}{results.netProfit.toFixed(2)}
                    </span>
                  </div>
                </div>
              </div>

              {/* VerificaciÃ³n */}
              <div className="mt-6 p-4 bg-muted/30 rounded-lg">
                <h4 className="font-bold mb-2 text-foreground">âœ“ VERIFICACIÃ“N:</h4>
                <ul className="text-sm space-y-1 text-muted-foreground">
                  <li>âœ“ Total series: {results.seriesWon} ganadas + {results.seriesLost} perdidas = {results.seriesWon + results.seriesLost} series</li>
                  <li>âœ“ PÃ©rdida por serie perdida: -${(results.allSeries.filter(s => s.result === 'lost')[0]?.stake || 0).toFixed(2)}</li>
                  <li>âœ“ Todas las operaciones procesadas: {results.totalTrades} trades</li>
                </ul>
              </div>
            </section>

            {/* DEBUG: CÃ¡lculos por Par */}
            {results.debugInfo && (
              <section className="p-6 rounded-lg bg-card border-2 border-warning">
                <h3 className="text-2xl font-bold mb-6 text-warning">ðŸ” DEBUG: CÃLCULOS DETALLADOS POR PAR</h3>
                
                {results.debugInfo.seriesDetails.map((detail, i) => (
                  <div key={i} className="mb-6 p-4 bg-muted/30 rounded-lg">
                    <h4 className="text-lg font-bold mb-3 text-foreground">{detail.pair}</h4>
                    <div className="space-y-2 font-mono text-sm">
                      {(detail as any).trades?.map((trade: any, j: number) => (
                        <div key={j} className="flex justify-between items-center p-2 bg-background/50 rounded">
                          <span>
                            {trade.time} {trade.emoji} 
                            {trade.emoji !== 'â›”ï¸' && <span className="text-muted-foreground"> (Nivel {trade.level})</span>}
                          </span>
                          <span className={trade.profit >= 0 ? 'text-success font-bold' : 'text-destructive font-bold'}>
                            {trade.profit >= 0 ? '+' : ''}{trade.profit.toFixed(2)}
                          </span>
                        </div>
                      ))}
                      <div className="h-px bg-border my-2"></div>
                      <div className="flex justify-between items-center p-2 bg-primary/10 rounded font-bold">
                        <span>TOTAL {detail.pair}:</span>
                        <span className={detail.netProfit >= 0 ? 'text-success' : 'text-destructive'}>
                          {detail.netProfit >= 0 ? '+' : ''}{detail.netProfit.toFixed(2)}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}

                <div className="mt-6 p-4 bg-warning/10 rounded-lg">
                  <h4 className="font-bold mb-2 text-warning">ðŸ“‹ VALORES DE GANANCIA NETA POR NIVEL:</h4>
                  <div className="space-y-1 text-sm font-mono">
                    {config.martingaleStructure.map((stake, idx) => {
                      const level = idx + 1;
                      const netProfit = stake * (config.payoutPercentage / 100);
                      const emoji = level === 1 ? 'âœ…' : level === 2 ? 'âœ…Â¹' : 'âœ…Â²';
                      return (
                        <div key={level}>
                          Nivel {level} ({emoji}): +${netProfit.toFixed(2)} (${stake.toFixed(2)} Ã— {config.payoutPercentage}%)
                        </div>
                      );
                    })}
                    <div>PÃ©rdida (â›”ï¸): -${config.martingaleStructure.reduce((sum, stake) => sum + stake, 0).toFixed(2)} (suma de todos los niveles: {config.martingaleStructure.join(' + ')})</div>
                  </div>
                </div>
              </section>
            )}
          </>
        )}
      </main>
    </div>
  );
};

export default Index;

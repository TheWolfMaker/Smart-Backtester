import { TradeSignal } from '@/types/backtest';

export const parseSignalFile = (content: string): TradeSignal[] => {
  const lines = content.split('\n').map(line => line.trim()).filter(line => line);
  const signals: TradeSignal[] = [];
  let currentDate = '';

  for (const line of lines) {
    // Check if line is a date (supports multiple formats)
    const dateMatch = line.match(/^(\d{2})[\/\-\.](\d{2})[\/\-\.](\d{4})$/);
    if (dateMatch) {
      currentDate = line;
      continue;
    }

    // Parse trade line: M1 EURUSD 00:45 PUT ✅¹
    // CORREGIDO: Ahora detecta ✅, ✅¹, ✅², ⛔️
    const tradeMatch = line.match(/^(M\d+)\s+([A-Z]{6})\s+(\d{2}:\d{2})\s+(PUT|CALL)\s+([✅⛔️][¹²]?)/);
    if (tradeMatch && currentDate) {
      const [, timeframe, pair, time, direction, resultEmoji] = tradeMatch;
      
      // Determinar nivel y resultado
      let result: 'win' | 'loss' = 'loss';
      let martingaleLevel = 1;
      
      if (resultEmoji.includes('✅')) {
        result = 'win';
        if (resultEmoji.includes('¹')) martingaleLevel = 2;
        else if (resultEmoji.includes('²')) martingaleLevel = 3;
        else martingaleLevel = 1;
      }
      
      signals.push({
        date: currentDate,
        timeframe,
        pair,
        time,
        direction: direction as 'PUT' | 'CALL',
        result,
        martingaleLevel, // Nivel en el que ganó
      });
    }
  }

  return signals;
};

export const filterSignalsByTime = (
  signals: TradeSignal[],
  startTime: string,
  endTime: string
): TradeSignal[] => {
  if (!startTime || !endTime) return signals;

  return signals.filter(signal => {
    const signalTime = signal.time;
    return signalTime >= startTime && signalTime <= endTime;
  });
};

import { TradeSignal, MartingaleSeries, BacktestResults, DailyResult } from '@/types/backtest';
import { BacktestConfig } from '@/components/ConfigurationPanel';

export const runBacktest = (
  signals: TradeSignal[],
  config: BacktestConfig
): BacktestResults => {
  let currentCapital = config.initialCapital;
  const allSeries: MartingaleSeries[] = [];
  const dailyResultsMap = new Map<string, DailyResult>();
  
  // SEGUIMIENTO MEJORADO del ciclo Martingala
  let currentCycle: {
    level: number;                    // Nivel actual (1, 2, 3...)
    trades: TradeSignal[];           // Señales en este ciclo
    totalInvested: number;           // Total apostado en este ciclo
  } | null = null;

  let longestWinStreak = 0;
  let longestLossStreak = 0;
  let currentWinStreak = 0;
  let currentLossStreak = 0;
  let maxDrawdown = 0;
  let peakCapital = config.initialCapital;

  console.log('🎯 INICIANDO BACKTEST CON ESTRUCTURA:', config.martingaleStructure);

  for (const signal of signals) {
    // INICIAR NUEVO CICLO si no hay uno activo
    if (!currentCycle) {
      currentCycle = {
        level: 1,  // Siempre empezar en nivel 1
        trades: [signal],
        totalInvested: config.martingaleStructure[0] // Apostar nivel 1
      };
    } else {
      // CONTINUAR CICLO EXISTENTE - siguiente nivel
      const nextLevel = currentCycle.level + 1;
      
      // VERIFICAR si existe el siguiente nivel en la estructura
      if (nextLevel <= config.martingaleStructure.length) {
        const nextStake = config.martingaleStructure[nextLevel - 1];
        currentCycle.level = nextLevel;
        currentCycle.trades.push(signal);
        currentCycle.totalInvested += nextStake;
      } else {
        // NO HAY MÁS NIVELES - forzar pérdida y reiniciar
        console.warn('❌ No hay más niveles en la estructura Martingala');
        currentCycle = {
          level: 1,
          trades: [signal],
          totalInvested: config.martingaleStructure[0]
        };
      }
    }

    // INICIALIZAR RESULTADO DIARIO
    if (!dailyResultsMap.has(signal.date)) {
      dailyResultsMap.set(signal.date, {
        date: signal.date,
        trades: 0,
        wins: 0,
        losses: 0,
        profit: 0,
        balance: currentCapital,
      });
    }

    const dailyResult = dailyResultsMap.get(signal.date)!;
    dailyResult.trades++;

    // CALCULAR RESULTADO BASADO EN EL NIVEL ACTUAL
    const currentStake = config.martingaleStructure[currentCycle.level - 1];
    
    if (signal.result === 'win') {
      // ✅ GANÓ EN ESTE NIVEL
      const profit = getNetProfitByLevel(currentCycle.level, config.payoutPercentage, config.martingaleStructure);
      
      console.log(`💰 GANANCIA: ${signal.pair} ${signal.time} Nivel ${currentCycle.level}`, {
        stake: currentStake,
        profit,
        capitalAntes: currentCapital,
        capitalDespues: currentCapital + profit
      });
      
      currentCapital += profit;
      
      // REGISTRAR SERIE GANADA
      allSeries.push({
        trades: [...currentCycle.trades],
        result: 'won',
        profit,
        stake: currentCycle.totalInvested,
      });

      dailyResult.wins++;
      dailyResult.profit += profit;
      currentWinStreak++;
      currentLossStreak = 0;
      longestWinStreak = Math.max(longestWinStreak, currentWinStreak);

      // REINICIAR CICLO (ganó en cualquier nivel)
      currentCycle = null;

    } else {
      // ❌ PERDIÓ EN ESTE NIVEL
      // VERIFICAR si hay siguiente nivel disponible
      const nextLevel = currentCycle.level + 1;
      const hasNextLevel = nextLevel <= config.martingaleStructure.length;

      if (hasNextLevel) {
        // HAY MÁS NIVELES - continuar ciclo en siguiente señal
        console.log(`➡️  Pérdida nivel ${currentCycle.level}, continuando al nivel ${nextLevel}`);
        // NO reiniciar ciclo - continuará en siguiente iteración
      } else {
        // ❌ PERDIÓ LA SERIE COMPLETA - último nivel perdido
        const totalLoss = currentCycle.totalInvested; // Solo lo apostado en ESTE ciclo
        
        console.log(`💀 SERIE PERDIDA: ${signal.pair} Nivel ${currentCycle.level}`, {
          totalLoss,
          capitalAntes: currentCapital,
          capitalDespues: currentCapital - totalLoss,
          tradesEnSerie: currentCycle.trades.length
        });

        currentCapital -= totalLoss;

        // REGISTRAR SERIE PERDIDA
        allSeries.push({
          trades: [...currentCycle.trades],
          result: 'lost',
          profit: -totalLoss,
          stake: totalLoss,
        });

        dailyResult.losses++;
        dailyResult.profit -= totalLoss;
        currentLossStreak++;
        currentWinStreak = 0;
        longestLossStreak = Math.max(longestLossStreak, currentLossStreak);

        // REINICIAR CICLO
        currentCycle = null;
      }
    }

    // ACTUALIZAR BALANCE DIARIO
    dailyResult.balance = currentCapital;

    // CALCULAR DRAWDOWN
    peakCapital = Math.max(peakCapital, currentCapital);
    const drawdown = peakCapital - currentCapital;
    maxDrawdown = Math.max(maxDrawdown, drawdown);
  }

  // CALCULAR MÉTRICAS FINALES
  const seriesWon = allSeries.filter(s => s.result === 'won').length;
  const seriesLost = allSeries.filter(s => s.result === 'lost').length;
  const totalSeries = seriesWon + seriesLost;

  // DEBUG INFO MEJORADA
  const debugSeriesDetails = allSeries.map((series, index) => {
    const lastTrade = series.trades[series.trades.length - 1];
    return {
      serie: index + 1,
      resultado: series.result,
      niveles: series.trades.length,
      profit: series.profit,
      par: lastTrade.pair,
      trades: series.trades.map(t => ({
        time: t.time,
        nivel: t.martingaleLevel,
        resultado: t.result
      }))
    };
  });

  return {
    totalTrades: signals.length,
    seriesWon,
    seriesLost,
    winRate: totalSeries > 0 ? (seriesWon / totalSeries) * 100 : 0,
    finalCapital: currentCapital,
    netProfit: currentCapital - config.initialCapital,
    maxDrawdown,
    longestWinStreak,
    longestLossStreak,
    dailyResults: Array.from(dailyResultsMap.values()),
    allSeries,
    debugInfo: {
      baseStake: config.martingaleStructure[0],
      seriesDetails: debugSeriesDetails
    }
  };
};

// FUNCIÓN MEJORADA - Cálculo preciso de ganancias
const getNetProfitByLevel = (level: number, payoutPercentage: number, martingaleStructure: number[]): number => {
  const currentStake = martingaleStructure[level - 1];
  
  if (!currentStake) {
    console.error(`❌ ERROR: Nivel ${level} no existe en la estructura:`, martingaleStructure);
    return 0;
  }
  
  // FÓRMULA CORRECTA: Ganancia NETA = Stake × (Payout% / 100)
  const netProfit = currentStake * (payoutPercentage / 100);
  
  console.log(`📊 Cálculo nivel ${level}: $${currentStake} × ${payoutPercentage}% = +$${netProfit.toFixed(2)}`);
  
  return parseFloat(netProfit.toFixed(2));
};
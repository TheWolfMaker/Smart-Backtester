import { Card } from '@/components/ui/card';
import { BacktestResults } from '@/types/backtest';
import { TrendingUp, TrendingDown, Target, Activity, BarChart3, DollarSign } from 'lucide-react';

interface ResultsMetricsProps {
  results: BacktestResults;
}

export const ResultsMetrics = ({ results }: ResultsMetricsProps) => {
  const metrics = [
    {
      label: 'Capital Final',
      value: `$${results.finalCapital.toFixed(2)}`,
      icon: DollarSign,
      color: results.netProfit >= 0 ? 'text-success' : 'text-destructive',
    },
    {
      label: 'Ganancia Neta',
      value: `$${results.netProfit.toFixed(2)}`,
      icon: results.netProfit >= 0 ? TrendingUp : TrendingDown,
      color: results.netProfit >= 0 ? 'text-success' : 'text-destructive',
    },
    {
      label: 'Tasa de Acierto',
      value: `${results.winRate.toFixed(1)}%`,
      icon: Target,
      color: results.winRate >= 50 ? 'text-success' : 'text-destructive',
    },
    {
      label: 'Series Totales',
      value: `${results.seriesWon + results.seriesLost}`,
      icon: BarChart3,
      color: 'text-primary',
    },
    {
      label: 'Drawdown Máximo',
      value: `${results.maxDrawdown.toFixed(1)}%`,
      icon: Activity,
      color: results.maxDrawdown > 20 ? 'text-destructive' : 'text-muted-foreground',
    },
    {
      label: 'Racha de Victorias',
      value: `${results.longestWinStreak}`,
      icon: TrendingUp,
      color: 'text-success',
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      {metrics.map((metric, index) => {
        const Icon = metric.icon;
        return (
          <Card
            key={index}
            className="p-6 bg-gradient-card shadow-card hover:shadow-glow transition-shadow duration-300"
          >
            <div className="flex items-start justify-between">
              <div className="space-y-2">
                <p className="text-sm text-muted-foreground">{metric.label}</p>
                <p className={`text-2xl font-bold ${metric.color}`}>{metric.value}</p>
              </div>
              <div className={`p-3 rounded-lg bg-secondary ${metric.color}`}>
                <Icon className="w-5 h-5" />
              </div>
            </div>
          </Card>
        );
      })}
    </div>
  );
};

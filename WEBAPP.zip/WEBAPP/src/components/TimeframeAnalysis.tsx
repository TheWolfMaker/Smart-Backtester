import { Card } from '@/components/ui/card';
import { TradeSignal, MartingaleSeries } from '@/types/backtest';
import { Clock, TrendingUp, TrendingDown } from 'lucide-react';

interface TimeframeAnalysisProps {
  allSeries: MartingaleSeries[];
  config: { timeframeFilter: 'M1' | 'M5' | 'ALL' };
}

export const TimeframeAnalysis = ({ allSeries, config }: TimeframeAnalysisProps) => {
  // Analizar por temporalidad
  const m1Series = allSeries.filter(series => 
    series.trades.some(t => t.timeframe === 'M1')
  );
  const m5Series = allSeries.filter(series => 
    series.trades.some(t => t.timeframe === 'M5')
  );

  const calculateStats = (series: MartingaleSeries[]) => {
    const won = series.filter(s => s.result === 'won').length;
    const lost = series.filter(s => s.result === 'lost').length;
    const totalProfit = series.reduce((sum, s) => sum + s.profit, 0);
    const winRate = series.length > 0 ? (won / series.length) * 100 : 0;

    return { won, lost, totalProfit, winRate, total: series.length };
  };

  const m1Stats = calculateStats(m1Series);
  const m5Stats = calculateStats(m5Series);

  if (config.timeframeFilter !== 'ALL') {
    return null; // Solo mostrar cuando esté en modo combinado
  }

  return (
    <Card className="p-6 bg-gradient-card shadow-card">
      <div className="flex items-center gap-2 mb-6">
        <div className="p-2 rounded-lg bg-primary/10">
          <Clock className="w-5 h-5 text-primary" />
        </div>
        <h3 className="text-xl font-semibold">Análisis por Temporalidad</h3>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* M1 Stats */}
        <div className="p-6 rounded-lg bg-muted/30 border border-border">
          <h4 className="text-lg font-bold mb-4 text-primary flex items-center gap-2">
            <span className="px-3 py-1 bg-primary/20 rounded-full text-sm">M1</span>
            <span className="text-muted-foreground text-sm">({m1Stats.total} series)</span>
          </h4>
          
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-muted-foreground">Series Ganadas:</span>
              <span className="text-success font-bold">{m1Stats.won}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-muted-foreground">Series Perdidas:</span>
              <span className="text-destructive font-bold">{m1Stats.lost}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-muted-foreground">Win Rate:</span>
              <span className={`font-bold ${m1Stats.winRate >= 50 ? 'text-success' : 'text-destructive'}`}>
                {m1Stats.winRate.toFixed(1)}%
              </span>
            </div>
            <div className="h-px bg-border my-2"></div>
            <div className="flex justify-between items-center">
              <span className="font-bold">Ganancia Neta:</span>
              <span className={`text-lg font-bold ${m1Stats.totalProfit >= 0 ? 'text-success' : 'text-destructive'}`}>
                {m1Stats.totalProfit >= 0 ? '+' : ''}${m1Stats.totalProfit.toFixed(2)}
              </span>
            </div>
          </div>
        </div>

        {/* M5 Stats */}
        <div className="p-6 rounded-lg bg-muted/30 border border-border">
          <h4 className="text-lg font-bold mb-4 text-primary flex items-center gap-2">
            <span className="px-3 py-1 bg-primary/20 rounded-full text-sm">M5</span>
            <span className="text-muted-foreground text-sm">({m5Stats.total} series)</span>
          </h4>
          
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-muted-foreground">Series Ganadas:</span>
              <span className="text-success font-bold">{m5Stats.won}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-muted-foreground">Series Perdidas:</span>
              <span className="text-destructive font-bold">{m5Stats.lost}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-muted-foreground">Win Rate:</span>
              <span className={`font-bold ${m5Stats.winRate >= 50 ? 'text-success' : 'text-destructive'}`}>
                {m5Stats.winRate.toFixed(1)}%
              </span>
            </div>
            <div className="h-px bg-border my-2"></div>
            <div className="flex justify-between items-center">
              <span className="font-bold">Ganancia Neta:</span>
              <span className={`text-lg font-bold ${m5Stats.totalProfit >= 0 ? 'text-success' : 'text-destructive'}`}>
                {m5Stats.totalProfit >= 0 ? '+' : ''}${m5Stats.totalProfit.toFixed(2)}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Comparación */}
      <div className="mt-6 p-4 bg-primary/10 rounded-lg">
        <h4 className="font-bold mb-3 text-foreground">📊 Comparación:</h4>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
          <div className="flex items-center gap-2">
            {m1Stats.winRate >= m5Stats.winRate ? (
              <TrendingUp className="w-4 h-4 text-success" />
            ) : (
              <TrendingDown className="w-4 h-4 text-muted-foreground" />
            )}
            <span>M1 tiene {Math.abs(m1Stats.winRate - m5Stats.winRate).toFixed(1)}% {m1Stats.winRate >= m5Stats.winRate ? 'más' : 'menos'} win rate</span>
          </div>
          <div className="flex items-center gap-2">
            {m1Stats.totalProfit >= m5Stats.totalProfit ? (
              <TrendingUp className="w-4 h-4 text-success" />
            ) : (
              <TrendingDown className="w-4 h-4 text-muted-foreground" />
            )}
            <span>M1 genera ${Math.abs(m1Stats.totalProfit - m5Stats.totalProfit).toFixed(2)} {m1Stats.totalProfit >= m5Stats.totalProfit ? 'más' : 'menos'} ganancia</span>
          </div>
        </div>
      </div>
    </Card>
  );
};

import { useState } from 'react';
import { Upload, FileText } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

interface FileUploadProps {
  onFileUpload: (content: string, filename: string) => void;
}

export const FileUpload = ({ onFileUpload }: FileUploadProps) => {
  const [isDragging, setIsDragging] = useState(false);
  const [fileName, setFileName] = useState<string>("");

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    
    const file = e.dataTransfer.files[0];
    if (file && file.type === 'text/plain') {
      readFile(file);
    }
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      readFile(file);
    }
  };

  const readFile = (file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const content = e.target?.result as string;
      setFileName(file.name);
      onFileUpload(content, file.name);
    };
    reader.readAsText(file);
  };

  return (
    <Card className="p-8 border-2 border-dashed transition-all duration-300 bg-card hover:border-primary/50">
      <div
        className={`flex flex-col items-center justify-center gap-4 transition-colors ${
          isDragging ? 'opacity-50' : ''
        }`}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
      >
        <div className="p-4 rounded-full bg-primary/10">
          <Upload className="w-8 h-8 text-primary" />
        </div>
        
        <div className="text-center space-y-2">
          <h3 className="text-lg font-semibold">Cargar Señales de Trading</h3>
          <p className="text-sm text-muted-foreground">
            Arrastra y suelta tu archivo .txt aquí o haz clic para buscar
          </p>
        </div>

        {fileName && (
          <div className="flex items-center gap-2 text-sm text-muted-foreground bg-secondary px-4 py-2 rounded-lg">
            <FileText className="w-4 h-4" />
            <span>{fileName}</span>
          </div>
        )}

        <input
          type="file"
          accept=".txt"
          onChange={handleFileInput}
          className="hidden"
          id="file-upload"
        />
        <label htmlFor="file-upload">
          <Button variant="default" className="cursor-pointer" asChild>
            <span>Elegir Archivo</span>
          </Button>
        </label>
      </div>
    </Card>
  );
};

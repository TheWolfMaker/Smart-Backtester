import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { DailyResult } from '@/types/backtest';
import { Download, Table as TableIcon } from 'lucide-react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';

interface ResultsTableProps {
  dailyResults: DailyResult[];
}

export const ResultsTable = ({ dailyResults }: ResultsTableProps) => {
  const exportToCSV = () => {
    const headers = ['Fecha', 'Operaciones', 'Ganadas', 'Perdidas', 'Ganancia', 'Balance'];
    const rows = dailyResults.map((day) => [
      day.date,
      day.trades,
      day.wins,
      day.losses,
      day.profit.toFixed(2),
      day.balance.toFixed(2),
    ]);

    const csv = [
      headers.join(','),
      ...rows.map((row) => row.join(',')),
    ].join('\n');

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `backtest-results-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
  };

  return (
    <Card className="p-6 bg-gradient-card shadow-card">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-2">
          <div className="p-2 rounded-lg bg-primary/10">
            <TableIcon className="w-5 h-5 text-primary" />
          </div>
          <h2 className="text-xl font-semibold">Resultados Diarios</h2>
        </div>
        <Button
          variant="outline"
          size="sm"
          onClick={exportToCSV}
          className="gap-2"
        >
          <Download className="w-4 h-4" />
          Exportar CSV
        </Button>
      </div>

      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow className="border-border hover:bg-secondary/50">
              <TableHead>Fecha</TableHead>
              <TableHead className="text-right">Operaciones</TableHead>
              <TableHead className="text-right">Ganadas</TableHead>
              <TableHead className="text-right">Perdidas</TableHead>
              <TableHead className="text-right">Ganancia</TableHead>
              <TableHead className="text-right">Balance</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {dailyResults.map((day, index) => (
              <TableRow key={index} className="border-border hover:bg-secondary/30">
                <TableCell className="font-medium">{day.date}</TableCell>
                <TableCell className="text-right">{day.trades}</TableCell>
                <TableCell className="text-right text-success">{day.wins}</TableCell>
                <TableCell className="text-right text-destructive">{day.losses}</TableCell>
                <TableCell
                  className={`text-right font-semibold ${
                    day.profit >= 0 ? 'text-success' : 'text-destructive'
                  }`}
                >
                  ${day.profit.toFixed(2)}
                </TableCell>
                <TableCell className="text-right font-semibold">
                  ${day.balance.toFixed(2)}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </Card>
  );
};

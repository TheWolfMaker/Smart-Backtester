import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Settings, Calculator, AlertCircle } from 'lucide-react';
import { useState } from 'react';

export interface BacktestConfig {
  payoutPercentage: number;
  initialCapital: number;
  martingaleStructure: number[];
  startTime: string;
  endTime: string;
  timeframeFilter: 'M1' | 'M5' | 'ALL';
}

interface ConfigurationPanelProps {
  config: BacktestConfig;
  onConfigChange: (config: BacktestConfig) => void;
  onRunBacktest: () => void;
  disabled?: boolean;
}

export const ConfigurationPanel = ({
  config,
  onConfigChange,
  onRunBacktest,
  disabled = false,
}: ConfigurationPanelProps) => {
  const [structureError, setStructureError] = useState<string>('');

  const handleStructureChange = (value: string) => {
    // Permitir coma Y guión como separadores
    const structure = value
      .split(/[,-]/) // acepta tanto "," como "-"
      .map((v) => parseFloat(v.trim()))
      .filter((v) => !isNaN(v));
    
    // Validaciones
    if (structure.length === 0) {
      setStructureError('Ingresa al menos un nivel');
      return;
    }
    
    if (structure.some(v => v <= 0)) {
      setStructureError('Los valores deben ser mayores a 0');
      return;
    }
    
    if (structure.length > 10) {
      setStructureError('Máximo 10 niveles');
      return;
    }
    
    setStructureError('');
    onConfigChange({ ...config, martingaleStructure: structure });
  };

  const getStructureDisplay = () => {
    return config.martingaleStructure.join('-');
  };

  const calculateMartingaleStats = () => {
    const { martingaleStructure, payoutPercentage } = config;
    if (martingaleStructure.length === 0) return null;

    const totalRisk = martingaleStructure.reduce((sum, stake) => sum + stake, 0);
    const profitPerLevel = martingaleStructure.map((stake, index) => ({
      level: index + 1,
      stake,
      profit: stake * (payoutPercentage / 100),
      loss: stake
    }));

    return { totalRisk, profitPerLevel };
  };

  const applyPreset = (preset: number[]) => {
    onConfigChange({ ...config, martingaleStructure: preset });
    setStructureError('');
  };

  const stats = calculateMartingaleStats();

  return (
    <Card className="p-6 bg-gradient-card shadow-card">
      <div className="flex items-center gap-2 mb-6">
        <div className="p-2 rounded-lg bg-primary/10">
          <Settings className="w-5 h-5 text-primary" />
        </div>
        <h2 className="text-xl font-semibold">Configuración del Backtest</h2>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {/* Payout Percentage */}
        <div className="space-y-2">
          <Label htmlFor="payout">Payout (%)</Label>
          <Input
            id="payout"
            type="number"
            value={config.payoutPercentage}
            onChange={(e) =>
              onConfigChange({ ...config, payoutPercentage: parseFloat(e.target.value) || 0 })
            }
            min="1"
            max="100"
            step="1"
            className="bg-secondary border-border"
          />
          <p className="text-xs text-muted-foreground">
            Porcentaje de ganancia por trade
          </p>
        </div>

        {/* Initial Capital */}
        <div className="space-y-2">
          <Label htmlFor="capital">Capital Inicial ($)</Label>
          <Input
            id="capital"
            type="number"
            value={config.initialCapital}
            onChange={(e) =>
              onConfigChange({ ...config, initialCapital: parseFloat(e.target.value) || 0 })
            }
            min="0"
            step="10"
            className="bg-secondary border-border"
          />
        </div>

        {/* Martingale Structure - MEJORADO */}
        <div className="space-y-2">
          <Label htmlFor="structure">
            Estructura Martingala
            {stats && (
              <span className="ml-2 text-xs font-normal text-muted-foreground">
                (Riesgo: ${stats.totalRisk})
              </span>
            )}
          </Label>
          <Input
            id="structure"
            type="text"
            value={getStructureDisplay()}
            onChange={(e) => handleStructureChange(e.target.value)}
            placeholder="1,2,4 o 1-2-4"
            className={`bg-secondary border-border ${structureError ? 'border-destructive' : ''}`}
          />
          {structureError ? (
            <div className="flex items-center gap-1 text-destructive text-xs">
              <AlertCircle className="w-3 h-3" />
              {structureError}
            </div>
          ) : (
            <p className="text-xs text-muted-foreground">
              Separar con comas o guiones (ej: 1,2,4 o 1-2-4)
            </p>
          )}
        </div>

        {/* Start Time */}
        <div className="space-y-2">
          <Label htmlFor="startTime">Hora de Inicio</Label>
          <Input
            id="startTime"
            type="time"
            value={config.startTime}
            onChange={(e) => onConfigChange({ ...config, startTime: e.target.value })}
            className="bg-secondary border-border"
          />
        </div>

        {/* End Time */}
        <div className="space-y-2">
          <Label htmlFor="endTime">Hora de Fin</Label>
          <Input
            id="endTime"
            type="time"
            value={config.endTime}
            onChange={(e) => onConfigChange({ ...config, endTime: e.target.value })}
            className="bg-secondary border-border"
          />
        </div>

        {/* Timeframe Filter */}
        <div className="space-y-2">
          <Label htmlFor="timeframe">Temporalidad</Label>
          <Select
            value={config.timeframeFilter}
            onValueChange={(value: 'M1' | 'M5' | 'ALL') =>
              onConfigChange({ ...config, timeframeFilter: value })
            }
          >
            <SelectTrigger className="bg-secondary border-border">
              <SelectValue placeholder="Seleccionar temporalidad" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="ALL">Combinado (M1 + M5)</SelectItem>
              <SelectItem value="M1">Solo M1</SelectItem>
              <SelectItem value="M5">Solo M5</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* PRESETS RÁPIDOS - NUEVO */}
      <div className="mt-6 p-4 bg-muted/30 rounded-lg">
        <Label className="flex items-center gap-2 mb-3">
          <Calculator className="w-4 h-4" />
          Estrategias Predefinidas
        </Label>
        <div className="flex flex-wrap gap-2">
          {[
            { name: 'Clásico', structure: [1, 2, 4] },
            { name: 'Moderado', structure: [1, 2, 3, 5] },
            { name: 'Agresivo', structure: [1, 3, 7, 15] },
            { name: 'Flat', structure: [1, 1, 1, 1] },
            { name: 'Fibonacci', structure: [1, 1, 2, 3, 5] },
          ].map((preset) => (
            <Button
              key={preset.name}
              variant="outline"
              size="sm"
              onClick={() => applyPreset(preset.structure)}
              className="text-xs"
            >
              {preset.name} [{preset.structure.join(',')}]
            </Button>
          ))}
        </div>
      </div>

      {/* ESTADÍSTICAS EN TIEMPO REAL - NUEVO */}
      {stats && stats.profitPerLevel.length > 0 && (
        <div className="mt-4 p-4 bg-primary/5 rounded-lg border border-primary/20">
          <Label className="text-sm font-medium mb-2 block">
            📊 Ganancia por Nivel (Payout {config.payoutPercentage}%)
          </Label>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-2 text-xs">
            {stats.profitPerLevel.map(({ level, stake, profit, loss }) => (
              <div key={level} className="text-center p-2 bg-background/50 rounded">
                <div className="font-bold">Nvl {level}</div>
                <div className="text-success">+${profit.toFixed(2)}</div>
                <div className="text-destructive text-xs">-${loss.toFixed(2)}</div>
                <div className="text-muted-foreground">Apuesta: ${stake}</div>
              </div>
            ))}
          </div>
          <div className="mt-2 pt-2 border-t border-border text-xs">
            <div className="flex justify-between">
              <span>Riesgo Total por Serie:</span>
              <span className="font-bold text-destructive">${stats.totalRisk.toFixed(2)}</span>
            </div>
            <div className="flex justify-between">
              <span>Relación Riesgo/Beneficio:</span>
              <span className="font-bold">
                1:{((stats.profitPerLevel[0]?.profit || 0) / stats.totalRisk).toFixed(2)}
              </span>
            </div>
          </div>
        </div>
      )}

      {/* BOTÓN EJECUTAR */}
      <div className="flex items-end mt-6">
        <Button
          onClick={onRunBacktest}
          disabled={disabled || !!structureError}
          className="w-full bg-gradient-primary hover:opacity-90 transition-opacity"
        >
          Ejecutar Backtest
        </Button>
      </div>
    </Card>
  );
};